from Interface.preducer import RabbitMQProducer
from Server.Serverapp import RabbitMQProducer
if __name__ == '__main__':
    # Create a producer and send a message
    producer = RabbitMQProducer(host='localhost', queue_name='my_queue')
    message = {'name': 'John', 'age': 30}
    producer.sendMessage(message)